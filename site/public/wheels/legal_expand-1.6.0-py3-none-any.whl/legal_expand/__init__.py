"""
legal-expand - Expansión inteligente de siglas legales españolas

@author https://github.com/686f6c61
@repository https://github.com/686f6c61/pypi-legal-expand
@license MIT
@date 12/2025

Punto de entrada principal del paquete legal-expand para Python.
Librería para expandir automáticamente siglas legales en textos
jurídicos españoles, añadiendo su significado completo.

647 siglas legales verificadas de fuentes oficiales (RAE, BOE, DPEJ).

ARQUITECTURA:
Este módulo actúa como fachada pública del paquete, exponiendo:
1. Funciones principales de expansión (expandir_siglas, buscar_sigla)
2. Sistema de configuración global
3. Factory de formatters para extensibilidad
4. Tipos públicos para type hints

RESPONSABILIDADES:
- Exportar la API pública del paquete
- Proporcionar documentación de alto nivel
- Mantener compatibilidad de versiones
- Facilitar imports simplificados

INTEGRACIÓN CON OTROS MÓDULOS:
- core/engine: Motor principal de expansión
- core/matcher: Detección y validación de siglas
- config: Sistema de configuración global
- formatters: Transformación de salida
- types: Definiciones de tipos

Example:
    >>> from legal_expand import expandir_siglas
    >>> expandir_siglas('La AEAT notifica el IVA')
    'La AEAT (Agencia Estatal de Administración Tributaria) notifica el IVA (Impuesto sobre el Valor Añadido)'

    >>> from legal_expand import expandir_siglas, ExpansionOptions
    >>> expandir_siglas('La AEAT', ExpansionOptions(format='html'))
    'La <abbr title="Agencia...">AEAT</abbr> (Agencia...)'

    >>> from legal_expand import buscar_sigla
    >>> buscar_sigla('AEAT').meanings
    ['Agencia Estatal de Administración Tributaria']
"""

from __future__ import annotations

__version__ = "1.6.0"
__author__ = "686f6c61"

# ============================================================================
# FUNCIONES PRINCIPALES
# ============================================================================

from .core.engine import (
    auditar_texto,
    benchmark_texto,
    buscar_sigla,
    exportar_glosario,
    extraer_siglas,
    expandir_siglas,
    expandir_siglas_detallado,
    generar_glosario,
    listar_siglas,
    obtener_info_diccionario,
    obtener_estadisticas,
)
from .documents import (
    expandir_documento,
    procesar_archivo,
    procesar_directorio,
)
from .boe import (
    BOEClient,
    boe_overrides_template,
    boe_report_by_paragraph_markdown,
    boe_report_to_html,
    boe_report_to_markdown,
    detectar_referencias_boe,
    enriquecer_boe,
    explicar_referencia_boe,
    revisar_boe,
)

# ============================================================================
# CONFIGURACIÓN GLOBAL
# ============================================================================

from .config import (
    configurar_globalmente,
    obtener_configuracion_global,
    resetear_configuracion,
)

# ============================================================================
# FORMATTERS (EXTENSIBILIDAD)
# ============================================================================

from .formatters import Formatter, FormatterFactory

# ============================================================================
# TIPOS
# ============================================================================

from .types import (
    AcronymSearchResult,
    AuditReport,
    AuditStats,
    BatchResult,
    BenchmarkResult,
    BOEEnrichmentOutput,
    BOEEnrichmentStats,
    BOENorm,
    BOEOptions,
    BOEReference,
    BOEReferenceKind,
    BOEReferenceStatus,
    BOEReviewItem,
    BOEReviewOutput,
    BOEReviewSection,
    BOEReviewSummary,
    BOEUnitBlock,
    DictionaryInfo,
    DictionaryStats,
    DiagnosticOutput,
    ExtractedAcronym,
    ExtractionOutput,
    ExpandedAcronym,
    ExpansionOptions,
    GlossaryEntry,
    GlobalConfig,
    OmittedAcronym,
    OmittedAcronymReason,
    Position,
    Stats,
    StructuredOutput,
)

# ============================================================================
# EXPORTS PÚBLICOS
# ============================================================================

__all__ = [
    # Versión
    "__version__",
    "__author__",
    # Funciones principales
    "expandir_siglas",
    "expandir_siglas_detallado",
    "extraer_siglas",
    "generar_glosario",
    "exportar_glosario",
    "auditar_texto",
    "benchmark_texto",
    "expandir_documento",
    "procesar_archivo",
    "procesar_directorio",
    "buscar_sigla",
    "listar_siglas",
    "obtener_estadisticas",
    "obtener_info_diccionario",
    "detectar_referencias_boe",
    "enriquecer_boe",
    "boe_report_to_markdown",
    "boe_report_to_html",
    "boe_report_by_paragraph_markdown",
    "boe_overrides_template",
    "explicar_referencia_boe",
    "revisar_boe",
    "BOEClient",
    # Configuración global
    "configurar_globalmente",
    "obtener_configuracion_global",
    "resetear_configuracion",
    # Formatters
    "Formatter",
    "FormatterFactory",
    # Tipos
    "ExpansionOptions",
    "ExpandedAcronym",
    "StructuredOutput",
    "DiagnosticOutput",
    "ExtractionOutput",
    "ExtractedAcronym",
    "GlossaryEntry",
    "AuditReport",
    "AuditStats",
    "BatchResult",
    "BenchmarkResult",
    "BOEOptions",
    "BOENorm",
    "BOEUnitBlock",
    "BOEReference",
    "BOEReferenceKind",
    "BOEReferenceStatus",
    "BOEEnrichmentStats",
    "BOEEnrichmentOutput",
    "BOEReviewItem",
    "BOEReviewOutput",
    "BOEReviewSection",
    "BOEReviewSummary",
    "DictionaryInfo",
    "OmittedAcronym",
    "OmittedAcronymReason",
    "GlobalConfig",
    "AcronymSearchResult",
    "DictionaryStats",
    "Position",
    "Stats",
]
